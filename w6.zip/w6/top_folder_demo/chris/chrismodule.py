def bye():
	return "ALL DONE"