def show_the_welcome(lang):
    if lang == 1:
        return "Bonjour"
    elif lang == 2:
        return "你好"
    else:
        return "Good day."